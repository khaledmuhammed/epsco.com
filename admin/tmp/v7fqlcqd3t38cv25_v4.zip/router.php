<?php
$routerArr = array
        (
        array('type'=>'folder' , 'file'=>'abc.zip', 'path'=>'/'),
        array('type'=>'folder' , 'file'=>'abc2.zip', 'path'=>'/admin/'),
        array('type'=>'file' , 'file'=>'efg.txt', 'path'=>'/'),
        array('type'=>'file' , 'file'=>'efg2.txt', 'path'=>'/admin/')
        );
?>