<?php
$dbArr = array
        (
        "INSERT INTO `users` (`id`, `username`, `email`, `password`, `status`, `balance`, `date`) VALUES ('', 'tst', 'tst@abmegypt.com', 'tst', '1', '0', '2017-12-24 00:00:00');",
        "INSERT INTO `users` (`id`, `username`, `email`, `password`, `status`, `balance`, `date`) VALUES ('', 'tst', 'tst@abmegypt.com', 'tst', '1', '0', '2017-12-24 00:00:00');",
        "INSERT INTO `users` (`id`, `username`, `email`, `password`, `status`, `balance`, `date`) VALUES ('', 'tst', 'tst@abmegypt.com', 'tst', '1', '0', '2017-12-24 00:00:00');",
        );
?>