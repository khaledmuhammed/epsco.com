<?php

class data extends model
{
    protected $table = '`data`';
}

class admins extends model
{
    protected $table = '`admins`';
}

class items extends model
{
    protected $table = '`items`';
}

class cats extends model
{
    protected $table = '`cats`';
}

class news extends model
{
    protected $table = '`news`';
}
class gallerycat extends model
{
    protected $table = '`gallerycat`';
}
class gallery extends model
{
    protected $table = '`gallery`';
}
class config extends model
{
    protected $table = '`config`';
}
